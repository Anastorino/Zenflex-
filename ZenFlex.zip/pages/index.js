import Head from 'next/head';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProductCard from '../components/ProductCard';

export default function Home() {
  return (
    <div>
      <Head>
        <title>ZenFlex - Tapis de yoga éco-responsables</title>
      </Head>
      <Header />
      <main>
        <h1>Nos tapis de yoga</h1>
        <ProductCard
          title="Tapis ZenFlex Nature"
          price="49.99€"
          image="/tapis-nature.jpg"
        />
      </main>
      <Footer />
    </div>
  );
}
