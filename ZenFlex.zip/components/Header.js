export default function Header() {
  return (
    <header>
      <h1>ZenFlex</h1>
      <nav>
        <a href="/">Accueil</a>
        <a href="/produits">Produits</a>
      </nav>
    </header>
  );
}