export default function ProductCard({ title, price, image }) {
  return (
    <div className="product-card">
      <img src={image} alt={title} width="200" />
      <h2>{title}</h2>
      <p>{price}</p>
    </div>
  );
}