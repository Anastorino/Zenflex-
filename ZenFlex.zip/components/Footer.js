export default function Footer() {
  return (
    <footer>
      <p>&copy; 2025 ZenFlex. Tous droits réservés.</p>
    </footer>
  );
}